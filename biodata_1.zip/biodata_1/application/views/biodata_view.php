<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
    <title> BIODATA </title>
</head>
<body bgcolor="black">
<h2 align=center>
<p>
<pre> <font color=white> BIODATA </pre>
</p>
<table align=center border=2 cellspacing="5" cellpadding="5">
    <tr>
		<th bgcolor=black><font color=white> Nama </th>
		<th bgcolor=black><font color=white> Azi Rahmanuddin </th>
	</tr>
    <tr>
        <th bgcolor=black><font color=white> Nim </th>
		<th bgcolor=black><font color=white> 12181719 </th>
    </tr>
    <tr>
        <th bgcolor=black><font color=white> Kelas </th>
		<th bgcolor=black><font color=white> 12.3c.11 </th>
    </tr>
    <tr>
        <th bgcolor=black><font color=white> Jurusan </th>
		<th bgcolor=black><font color=white> Sistem Informasi </th>
    </tr>
</h2>
</table>
</body>
</html>